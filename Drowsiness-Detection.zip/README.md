# 💤 Drowsiness Detection Using OpenCV

## Overview
This project detects driver drowsiness using real-time facial landmark tracking with OpenCV and Dlib. When eyes remain closed for a few seconds, the system triggers an alarm.

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Download the Dlib model file:
   [shape_predictor_68_face_landmarks.dat (Download Link)](https://github.com/davisking/dlib-models/blob/master/shape_predictor_68_face_landmarks.dat.bz2)
3. Place it in the same folder as this script.
4. Run the program:
   ```bash
   python drowsiness_detection.py
   ```

## Authors
Developed by:  
**B. Bhanu Sai Prakash**, B. Avinash, B. Naga Karthik, and Ch. Tarun
